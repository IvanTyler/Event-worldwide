const initState = {
    user: '',
    id: '',
    events: '',
}

export default initState
