import QuickSearchForm from "../QuickSearchForm/QuickSearchForm";
import QuickSearchEventList from "../QuickSearchEventList/QuickSearchEventList";
function QuickSearchContainer() {

  return (
    <>
      <QuickSearchForm />
      <QuickSearchEventList />
    </>
  )
}

export default QuickSearchContainer;
